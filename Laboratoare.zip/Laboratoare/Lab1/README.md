# Lab 1

Scurta introducere in `pthread.h`:

- `pthread_create`

- `pthread_join`
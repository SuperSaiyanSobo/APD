# Laborator 8

Se rezolva probleme de *bakctracking* folosind `ExecutorService`. Fiecare nou
pas din recursivitate va deveni un nou *task* din *ExecutorService*

Problemele rezolvate sunt:
- colorarea unui graf
- problema reginelor
- DFS
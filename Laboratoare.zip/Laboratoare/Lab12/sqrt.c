#include <stdlib.h>

/**
 * @author cristian.chilipirea
 *
 */
int main(void)
{
    system("make -C ../Lab2 run_cores; make -C ../Lab2 clean");

    return 0;
}
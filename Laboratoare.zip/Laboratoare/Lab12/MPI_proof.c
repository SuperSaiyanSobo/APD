#include <stdio.h>

int main(void)
{
	printf("\"Prove that you can write an MPI program that scales with the number of processes even on a single machine.\"\n\n");
	printf("https://github.com/teodutu/APD/tree/master/Laboratoare/Lab9\n");
	printf("https://github.com/teodutu/APD/tree/master/Laboratoare/Lab10\n");
	printf("https://github.com/teodutu/APD/tree/master/Laboratoare/Lab11\n");
	printf("\nCred ca am destule dovezi...\n");
}